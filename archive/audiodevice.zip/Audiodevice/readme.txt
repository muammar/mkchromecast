Type "audiodevice help" to print this usage message.

Usage:
audiodevice   // list devices for input, output, and system audio
audiodevice <port>   // display the audio device for the selected port
audiodevice <port> list   // list available audio devices for the selected port
audiodevice <port> <device>   // set the selected port to use the designated device ("internal" will select Internal Speakers or Headphones, whichever is active)